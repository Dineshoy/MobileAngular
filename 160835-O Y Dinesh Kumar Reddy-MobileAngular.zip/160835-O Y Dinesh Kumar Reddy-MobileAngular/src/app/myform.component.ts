import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Mobile} from './mobile.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{												//Myform class
    mob:Mobile;
    mobList:Mobile[]=[];
    constructor(private mser:Myservice){
        this.mob ={mobId:0,mobName:"",mobPrice:0};
    }
    ngOnInit(){
      
        this.mser.getAllMobiles().subscribe(result=>this.mobList=result);
    }
 
    
    
    sortId(){																		//function to sort by Mobile Id
     	 this.mobList.sort(function(a,b){return a.mobId-b.mobId);
        }
    
    
     sortName(){																		//function to sort by Mobile Name
         this.mobList.sort(function(a,b){
            if(a.mobName<b.mobName)
            return -1;
         else if(a.mobName>b.mobName)   
            return 1;   
            else return 0;
        });
        }
        
        
      sortPrice(){																	//function to sort by Mobile Price
         this.mobList.sort(function(a,b){return a.mobPrice-b.mobPrice});
        }
        
    	
  
     deleteId(mobId:any){															//Delete Function
    	for(var i=0;i<this.mobList.length;i++)
     {
        if(this.mobList[i]["mobId"]==mobId)    
        this.mobList.splice(i,1);
 	 }
   }
}
  