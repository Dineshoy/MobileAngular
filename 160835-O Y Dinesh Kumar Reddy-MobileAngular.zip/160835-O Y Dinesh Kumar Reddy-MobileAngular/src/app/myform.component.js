"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var myservice_1 = require("./myservice");
var MyForm = (function () {
    function MyForm(mser) {
        this.mser = mser;
        this.mobList = [];
        this.mob = { mobId: 0, mobName: "", mobPrice: 0 };
    }
    MyForm.prototype.ngOnInit = function () {
        var _this = this;
        this.mser.getAllMobiles().subscribe(function (result) { return _this.mobList = result; });
    };
    MyForm.prototype.sortId = function () {
        this.mobList.sort(function (a, b) { return a.mobId - b.mobId; });
    };
    MyForm.prototype.sortName = function () {
        this.mobList.sort(function (a, b) {
            if (a.mobName < b.mobName)
                return -1;
            else if (a.mobName > b.mobName)
                return 1;
            else
                return 0;
        });
    };
    MyForm.prototype.sortPrice = function () {
        this.mobList.sort(function (a, b) { return a.mobPrice - b.mobPrice; });
    };
    MyForm.prototype.deleteId = function (mobId) {
        for (var i = 0; i < this.mobList.length; i++) {
            if (this.mobList[i]["mobId"] == mobId)
                this.mobList.splice(i, 1);
        }
    };
    return MyForm;
}());
MyForm = __decorate([
    core_1.Component({
        selector: "my-form",
        templateUrl: './myform.component.html',
        providers: [myservice_1.Myservice]
    }),
    __metadata("design:paramtypes", [myservice_1.Myservice])
], MyForm);
exports.MyForm = MyForm;
